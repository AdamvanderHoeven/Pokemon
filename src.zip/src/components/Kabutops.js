export default function Kabutops() {
  return (
    <div>
      <h1>Happy may very well be a nutsack... </h1>
    </div>
  );
}
